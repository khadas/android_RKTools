================================================================================
factoryTool
Mail:lsh@rock-chips.com
================================================================================
[2021-07-19]1.72.9
1 add misc offset  config for android10 later(>= android10: MiscMsgOffset=0 <android10: MiscMsgOffset=32 )
[2021-06-10]1.72.8
1 fix demo image partition name match
1 enable resize window
[2021-05-21]1.72.7
1 add ignore serial configs
[2021-04-30]1.72.6
1 update upgradeLib v2.32
[2021-03-11]1.72.3
1 add bits compare for efuse
[2021-01-27]1.72
1 add writing flag("start"/"end") to vendor proc
[2020-08-03]1.7.02
1 update upgradeLib
[2020-05-07]1.7
1 add Project.ini for project config, such as path saving, reboot sleep time
[2020-04-02]1.69.02
1 merge with master branch
2 ignore read sn error
[2020-03-25]1.69
1、add read sn before download option
[2018-09-10]1.68.01
1、exit if no efuce when checking efuse
[2018-09-10]1.68
1、add check efuse before burn efuse
2、remove redundant codes
